package com.example.atividaderecycleview;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

class ViewHolderProduto extends RecyclerView.ViewHolder {

    private View itemView;

    public ViewHolderProduto(View view){
        super(view);
        itemView = view;
    }

    public void bind(Produto produto){
        TextView textNome = itemView.findViewById(R.id.cardView_txtView_Nome);
        TextView textModelo = itemView.findViewById(R.id.cardView_txtView_Modelo);
        TextView texMarca = itemView.findViewById(R.id.cardView_txtView_Marca);
        TextView texDescricao= itemView.findViewById(R.id.cardView_txtView_Descricao);
        TextView texPreco = itemView.findViewById(R.id.cardView_txtView_Preco);
        ImageView imageView = itemView.findViewById(R.id.cardView_imgView_Image);

        textNome.setText(produto.getNome());
        textModelo.setText(produto.getModelo());
        texMarca.setText( produto.getMarca());
        texDescricao.setText(produto.getDescricao());
        texPreco.setText( produto.getPreco());
        imageView.setImageDrawable(ContextCompat.getDrawable(itemView.getContext(), produto.getIdImagem()));

        Toast.makeText(itemView.getContext(), textNome.getText(), Toast.LENGTH_SHORT).show();
    }
}
