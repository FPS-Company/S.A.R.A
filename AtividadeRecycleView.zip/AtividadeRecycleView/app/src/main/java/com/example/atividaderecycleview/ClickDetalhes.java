package com.example.atividaderecycleview;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class ClickDetalhes  extends AppCompatActivity{
    //Declaração das variáveis
    private TextView nome,marca , descricao, preco, quantidade, modelo;



    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_click_detalhes);
        getSupportActionBar().hide();

        Produto produto = getIntent().getExtras().getParcelable("data");

        // Pegando as referencias das váriaveis
        TextView txtNome = findViewById(R.id.clickDetalhes_txtView_Nome);
        TextView txtModelo = findViewById(R.id.clickDetalhes_txtView_Modelo);
        TextView txtMarca = findViewById(R.id.clickDetalhes_txtView_Marca);
        TextView txtQuantidade= findViewById(R.id.clickDetalhes_txtView_Quantidade);
        TextView txtPreco = findViewById(R.id.clickDetalhes_txtView_Preco);
        TextView txtDescricao = findViewById(R.id.clickDetalhes_txtView_Descricao);



        //obter os valores armazenados na intent
        String nome = produto.getNome();
        String modelo = produto.getModelo();
        String marca = produto.getMarca();
        String quantidade = produto.getQuantidade();
        String preco = produto.getPreco();
        String descricao = produto.getDescricao();


        //setar os valores nos componentes
        txtNome.setText(nome);
        txtModelo.setText(modelo);
        txtMarca.setText(marca);
        txtQuantidade.setText(quantidade);
        txtPreco.setText(preco);
        txtDescricao.setText(descricao);



    }

}
