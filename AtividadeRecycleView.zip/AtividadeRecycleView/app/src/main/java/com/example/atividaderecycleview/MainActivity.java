package com.example.atividaderecycleview;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewProduto;
    private ArrayList<Produto> produtos;
    private Produto produto = new Produto();

    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        

        produtos = new ArrayList<>();
        produtos.add(new Produto("Produto 1", "modelo", "marca", "123 Peças", "R$ 132,00",R.drawable.ic_launcher_teste , "é um produto que talvez satisfaça as suas necessidades"));
        produtos.add(new Produto("Produto 2", "v 2.0", "Anonimus", "3 Peças", "R$ 1,00", R.drawable.ic_launcher_teste, "Não tem descrção"));



        recyclerViewProduto = findViewById(R.id.activity_main_recycleViwe);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerViewProduto.setLayoutManager(layoutManager);
        AdapterProduto adapter = new AdapterProduto(this, produtos);
        recyclerViewProduto.setAdapter(adapter);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.layout_manu_main_activity, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.layout_menu_main_activity_menuItem_sobre:
                Toast.makeText(this, "Tester", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
