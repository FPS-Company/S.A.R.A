 package com.example.atividaderecycleview;

 import android.content.Context;
 import android.content.Intent;
 import android.os.Parcelable;
 import android.view.LayoutInflater;
 import android.view.View;
 import android.view.ViewGroup;
 import android.widget.ImageView;
 import android.widget.TextView;
 import android.widget.Toast;

 import androidx.annotation.NonNull;
 import androidx.core.content.ContextCompat;
 import androidx.recyclerview.widget.RecyclerView;

 import java.util.List;

 public class AdapterProduto extends RecyclerView.Adapter<AdapterProduto.ViewHolder> {

     private LayoutInflater layoutInflater;
     private List<Produto> data;
     private Context context;

     AdapterProduto(Context context, List<Produto> data){
         this.layoutInflater = LayoutInflater.from(context);
         this.data = data;
     }

     @NonNull
     @Override
     public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
         View view = layoutInflater.inflate(R.layout.cardview,viewGroup,false);
         return new ViewHolder(view);

     }

     @Override
     public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
         Produto produto = data.get(i);
         viewHolder.bind(produto);
         // bind the textview with data received
         // similarly you can set new image for each card and descriptions
     }

     @Override
     public int getItemCount() {
         return data.size();
     }

     public class ViewHolder extends RecyclerView.ViewHolder{

         public ViewHolder(@NonNull View itemView) {
             super(itemView);
             itemView.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     Intent i = new Intent(v.getContext(), ClickDetalhes.class);
                     i.putExtra("data", data.get(getAdapterPosition()));
//                     i.putExtra("data", data.get(getAdapterPosition()));
//                     i.putExtra("data", data.get(getAdapterPosition()));
//                     i.putExtra("data", data.get(getAdapterPosition()));
//                     i.putExtra("data", data.get(getAdapterPosition()));
//                     i.putExtra("data", data.get(getAdapterPosition()));
                     v.getContext().startActivity(i);
                 }
             });
         }
         public void bind(Produto produto) {

             TextView textNome = itemView.findViewById(R.id.cardView_txtView_Nome);
             TextView textModelo = itemView.findViewById(R.id.cardView_txtView_Modelo);
             TextView texMarca = itemView.findViewById(R.id.cardView_txtView_Marca);
             TextView texQuantidade = itemView.findViewById(R.id.cardView_txtView_Quantidade);
             TextView texPreco = itemView.findViewById(R.id.cardView_txtView_Preco);
             ImageView imageView = itemView.findViewById(R.id.cardView_imgView_Image);

             textNome.setText(produto.getNome());
             textModelo.setText(produto.getModelo());
             texMarca.setText(produto.getMarca());
             texQuantidade.setText(produto.getQuantidade());
             texPreco.setText(produto.getPreco());
             imageView.setImageDrawable(ContextCompat.getDrawable(itemView.getContext(), produto.getIdImagem()));

             Toast.makeText(itemView.getContext(), textNome.getText(), Toast.LENGTH_SHORT).show();
         }
     }
 }

