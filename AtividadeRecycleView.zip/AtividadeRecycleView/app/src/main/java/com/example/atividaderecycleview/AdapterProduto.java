package com.example.atividaderecycleview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

    public class AdapterProduto extends RecyclerView.Adapter<ViewHolderProduto> {

        private List<Produto> produtos;
        private Context context;

        public AdapterProduto(List<Produto> produtos, Context context){
            this.produtos = produtos;
            this.context = context;
        }

        @NonNull
        @Override
        public ViewHolderProduto onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.cardview, parent, false);
            ViewHolderProduto holderProduto = new ViewHolderProduto(view);
            return holderProduto;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolderProduto holder, int position) {
            Produto produto = produtos.get(position);
            holder.bind(produto);
        }

        @Override
        public int getItemCount() {
            return produtos.size();
        }
    }


