package com.example.atividaderecycleview;

import android.os.Parcel;
import android.os.Parcelable;

public class Produto implements Parcelable {

    private String nome;
    private String modelo;
    private String marca;
    private String preco;
    private int idImagem;
    private String quantidade;
    private String descricao;

    public Produto() {

    }

    public Produto(String nome, String modelo, String marca, String quantidade, String preco, int idImagem, String descricao) {
        this.nome = nome;
        this.modelo = modelo;
        this.marca = marca;
        this.quantidade = quantidade;
        this.preco = preco;
        this.idImagem = idImagem;
        this.descricao = descricao;

    }

    protected Produto(Parcel in) {
        nome = in.readString();
        modelo = in.readString();
        marca = in.readString();
        preco = in.readString();
        idImagem = in.readInt();
        quantidade = in.readString();
        descricao = in.readString();
    }

    public static final Creator<Produto> CREATOR = new Creator<Produto>() {
        @Override
        public Produto createFromParcel(Parcel in) {
            return new Produto(in);
        }

        @Override
        public Produto[] newArray(int size) {
            return new Produto[size];
        }
    };

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public int getIdImagem() {
        return idImagem;
    }

    public void setIdImagem(int idImagem) {
        this.idImagem = idImagem;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nome);
        dest.writeString(modelo);
        dest.writeString(marca);
        dest.writeString(preco);
        dest.writeInt(idImagem);
        dest.writeString(quantidade);
        dest.writeString(descricao);
    }
}
