package com.example.atividaderecycleview;

public class Produto {

    private String nome;
    private String modelo;
    private String marca;
    private String descricao;
    private String preco;
    private int idImagem;

    public Produto() {

    }

    public Produto(String nome, String modelo, String marca, String descricao, String preco, int idImagem) {
        this.nome = nome;
        this.modelo = modelo;
        this.marca = marca;
        this.descricao = descricao;
        this.preco = preco;
        this.idImagem = idImagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public int getIdImagem() {
        return idImagem;
    }

    public void setIdImagem(int idImagem) {
        this.idImagem = idImagem;
    }
}
