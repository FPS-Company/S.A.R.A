package com.example.livro;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.livro.Model.Cadastrar_Livro;
import com.example.livro.Model.Gerenciar_Livro;
import androidx.appcompat.app.AppCompatActivity;

public class Cadastro_Livro extends AppCompatActivity {

    private EditText edtTitulo,edtISBN,edtNP,edtpreco;
    private Button btnCadastrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro__livro);

        edtTitulo = findViewById(R.id.cadastrar_Livro_activity_edttitulo);
        edtISBN = findViewById(R.id.cadastrar_Livro_activity_edtIsbn);
        edtNP = findViewById(R.id.cadastrar_Livro_activity_edtNP);
        edtpreco = findViewById(R.id.cadastrar_Livro_activity_edtpreco);
        btnCadastrar = findViewById(R.id.cadastrar_Livro_activity_Cadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Titulo = edtTitulo.getText().toString();
                String ISBN = edtISBN.getText().toString();
                String NumeroPaginas = edtNP.getText().toString();
                String preco = edtpreco.getText().toString();
                Cadastrar_Livro livro = new Cadastrar_Livro(Titulo,ISBN,NumeroPaginas,preco);
                Gerenciar_Livro.addLivro(livro);
                finish();
            }
        });
    }
}
