package com.example.livro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.livro.Model.Cadastrar_Livro;
import com.example.livro.Model.Gerenciar_Livro;

public class ListViewAlterar extends AppCompatActivity {
    private Button btnAlterar;
    private EditText edtTitulo,edtISBN,edtNP,edtpreco;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view_alterar);

        btnAlterar = findViewById(R.id.listview_Livro_activity_alterar);
        edtTitulo = findViewById(R.id.listview_Livro_activity_edtAutor);
        edtISBN = findViewById(R.id.listview_Livro_activity_edtTitulo);
        edtNP = findViewById(R.id.listview_Livro_activity_edtGenero);
        edtpreco = findViewById(R.id.listview_Livro_activity_edtpreco);

        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Titulo = edtTitulo.getText().toString();
                String ISBN = edtISBN.getText().toString();
                String Numeropaginas = edtNP.getText().toString();
                String preco = edtpreco.getText().toString();
                Cadastrar_Livro livro = new Cadastrar_Livro(Titulo,ISBN,Numeropaginas,preco);
                Gerenciar_Livro.addLivro(livro);
                Intent i = new Intent(ListViewAlterar.this, ListViewL.class);
                startActivity(i);
                finish();
            }
        });

    }

}
