package com.example.livro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.livro.Model.Cadastrar_Livro;
import com.example.livro.Model.Gerenciar_Livro;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton main_FloatingActionButton;
    private ListView main_listviewLivros;
    private ArrayAdapter<Cadastrar_Livro> adapterLivros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_FloatingActionButton = findViewById(R.id.main_floatingActionButton);
        main_listviewLivros = findViewById(R.id.main_listviewLivros);
        adapterLivros = new ArrayAdapter<Cadastrar_Livro>(this,android.R.layout.simple_list_item_1, Gerenciar_Livro.getLivros());

        //Adicionar um livro dentro de uma listview. Logo , ele está pegando um
        // arrayadapter que é um array que vai conter os valores que foram cadastrados no Gerenciar_Livros
        main_listviewLivros.setAdapter(adapterLivros);

        main_FloatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this,Cadastro_Livro.class);
               startActivity(i);
            }
        });
        main_listviewLivros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = new Intent(MainActivity.this, ListViewL.class);
                Cadastrar_Livro livro = Gerenciar_Livro.getLivros(position);
                i.putExtra("livro", livro);
                startActivity(i);
            }
        });

    }
}
