package com.example.livro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.livro.Model.Cadastrar_Livro;
import com.example.livro.Model.Gerenciar_Livro;

public class ListViewL extends AppCompatActivity {

    private TextView textTitulo, textisbn, textnumero, textpreco;
    private Button btnAlterar, btnRemover;
    Cadastrar_Livro l = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        textTitulo = findViewById(R.id.activity_exibir_dados_livro_textTitulo);
        textisbn = findViewById(R.id.activity_exibir_dados_livro_autor);
        textnumero = findViewById(R.id.activity_exibir_dados_livro_genero);
        textpreco = findViewById(R.id.activity_exibir_dados_livro_genero2);
        btnAlterar = findViewById(R.id.list_view_alterar);
        btnRemover = findViewById(R.id.list_view_Remover);

        Intent i = getIntent();
        if( i.getSerializableExtra("livro") != null) { // verificando se existe algo dentro da intent enviada da outra tela
            l = (Cadastrar_Livro) i.getSerializableExtra("livro");

            textTitulo.setText(l.getTitulo());
            textisbn.setText(l.getISBN());
            textnumero.setText(l.getNumeroPaginas());
            textpreco.setText(l.getNumeroPaginas());
        }

        btnAlterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ListViewL.this,ListViewAlterar.class);
                startActivity(i);
                Gerenciar_Livro.remover(l);
            }
        });

        btnRemover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Gerenciar_Livro.remover(l);
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_menu_alterar_remover, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.activity_exibir_filme_item_menu_remover:
                Gerenciar_Livro.remover(l);
                finish();
                break;
            case R.id.activity_exibir_filme_item_menu_alterar:
                Intent intentCadastrarlivro = new Intent(this, ListViewL.class);
                intentCadastrarlivro.putExtra("Livro", l);
                startActivity(intentCadastrarlivro);
                finish();
                break;
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
