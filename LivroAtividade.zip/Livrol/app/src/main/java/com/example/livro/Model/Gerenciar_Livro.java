package com.example.livro.Model;

import com.example.livro.Cadastro_Livro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Gerenciar_Livro {

        private static List<Cadastrar_Livro> Livros = new ArrayList<Cadastrar_Livro>(); //Cria uma Lista de livros,
    // como ele é static ele vai pertencer a todas as telas pois ele não pertence a própria classe

        public static void addLivro(Cadastrar_Livro livro) { //Função que vai instanciar um novo livro,
            // verificar se o livro está vazio e add esse livro na lista de livros
            if (livro != null) {
                Livros.add(livro);
            }
        }
        public static List<Cadastrar_Livro> getLivros() { //retornar os valores dos livros , ou seja ,
            // a lista de livros que foi adicionada no arryslist
            return Collections.unmodifiableList(Livros); // podemos retornar GetLivros() , entretanto, ela pode ser modificada,
            // quando utilizamos collections.unmodifiableList e passo como parâmetro o array livros fazendo ele se tornar imodificável

        }

    public static Cadastrar_Livro getLivros(int position) {
        if (position >= 0) {
            return Livros.get(position);
        }
        return null;
    }
    public static void remover(Cadastrar_Livro livro){
            Livros.remove(livro);
        }
    public static void alterar(Cadastrar_Livro livro, String titulo){
        for (int i = 0; i < Livros.size(); i++) {
            if(Livros.get(i).getTitulo().equals(titulo)){ // equals é um método para comparar o valor
                // significativo de um objeto cuja variável do tipo referência aponta.
                Livros.set(i,livro);
                break;
            }
        }
    }

    public static int getSize(){
            return Livros.size();
        }


}

