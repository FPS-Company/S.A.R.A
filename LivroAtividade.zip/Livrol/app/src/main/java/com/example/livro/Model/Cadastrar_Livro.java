package com.example.livro.Model;

import com.example.livro.Cadastro_Livro;

import java.io.Serializable;
import java.util.Objects;

public class Cadastrar_Livro implements Serializable { //faz com que o código seja transformado em bitcodes e
    // eu consigo enviar os dados de um objeto para a próxima activity
    private String Titulo,ISBN,NumeroPaginas,preco;

    public Cadastrar_Livro(){

    }
    public Cadastrar_Livro(String Titulo,String ISBN,String NumeroPaginas,String preco){
        this.Titulo = Titulo ;
        this.ISBN = ISBN;
        this.NumeroPaginas = NumeroPaginas;
        this.preco = preco;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getNumeroPaginas() {
        return NumeroPaginas;
    }

    public void setNumeroPaginas(String numeroPaginas) {
        NumeroPaginas = numeroPaginas;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return "Título: " + this.getTitulo() + ", ISBN:" + this.getISBN() + ", N° de Páginas :" + this.getNumeroPaginas() + ", Preço : " + this.getPreco();
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cadastrar_Livro livro = (Cadastrar_Livro) o;
        return Objects.equals(Titulo, livro.Titulo) &&
                Objects.equals(ISBN, livro.ISBN) &&
                Objects.equals(NumeroPaginas, livro.NumeroPaginas) &&
                Objects.equals(preco,livro.preco);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Titulo,ISBN,NumeroPaginas,preco);
    }
}




