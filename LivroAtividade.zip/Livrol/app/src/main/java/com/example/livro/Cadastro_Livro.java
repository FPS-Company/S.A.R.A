package com.example.livro;



import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.livro.Model.Cadastrar_Livro;
import com.example.livro.Model.Gerenciar_Livro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Cadastro_Livro extends AppCompatActivity {

    private EditText edtTitulo,edtISBN,edtNP,edtpreco;
    private Intent ReceberDados;
    Cadastrar_Livro l = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro__livro);

        edtTitulo = findViewById(R.id.cadastrar_Livro_activity_edttitulo);
        edtISBN = findViewById(R.id.cadastrar_Livro_activity_edtIsbn);
        edtNP = findViewById(R.id.cadastrar_Livro_activity_edtNP);
        edtpreco = findViewById(R.id.cadastrar_Livro_activity_edtpreco);

        ReceberDados = getIntent();
        if(ReceberDados.hasExtra("Livro")){
            getSupportActionBar().setTitle("Alterar Livro");
           l = (Cadastrar_Livro) ReceberDados.getSerializableExtra("Livro");
            edtTitulo.setText(l.getTitulo());
            edtISBN.setText(l.getISBN());
            edtNP.setText(l.getNumeroPaginas());
            edtpreco.setText(l.getPreco());
        }else{
            getSupportActionBar().setTitle("Cadastrar Livro");
        }

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_cadastrar_livro_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.activity_acadastrar_livro_item_menu_cadastrar){

            if(ReceberDados.hasExtra("Livro")){
                Cadastrar_Livro LivroAlterado = new Cadastrar_Livro(edtTitulo.getText().toString(),edtISBN.getText().toString(),
                        edtNP.getText().toString(),edtpreco.getText().toString());
                Gerenciar_Livro.alterar(LivroAlterado, l.getTitulo());
                finish();
            }else{
                String titulo = edtTitulo.getText().toString();
                String ISBN = edtISBN.getText().toString();
                String numeropaginas = edtNP.getText().toString();
                String preco = edtpreco.getText().toString();
                Cadastrar_Livro Livro = new Cadastrar_Livro(titulo,ISBN,numeropaginas,preco);
                Gerenciar_Livro.addLivro(Livro);

                finish();
            }
        }

        if(id == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
